package com.company;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.stream.IntStream;

public class Main {

    public static void main(String[] args) {
        //lambda();
        //optional();
        //methodReference();
        //defaultStaticMethods();
        //javaDate();
        //streamApiTest1();
        //streamApiTest2();
    }

    static void lambda() {

        Printable printable1 = (String greeting) -> {
            System.out.println(greeting.toUpperCase());
        };

        String greeting1 = "Hello Anna";

        printable1.print(greeting1);
    }

    static void optional() {
        String str = "China";

        Optional<String> optional = stringProcessor(str);

        optional.ifPresent((s) -> System.out.println(s.substring(0, 2)));
    }

    static void methodReference() {
        Optional<String> optional = Optional.of("Anna");

        optional.ifPresent((s) -> System.out.println(s));

        optional.ifPresent(System.out::println);
    }

    static void defaultStaticMethods() {
        Printable printable = (greeting) -> {
            System.out.println("greeting = " + greeting);
        };

        printable.print("asdasd");
        printable.defaultGreeting();

        String kk = Printable.getSubstring("AAA", 0, 1);
        System.out.println("kk = " + kk);
    }

    static void javaDate() {
        LocalDate localDate = LocalDate.of(2021, 10, 22);
        System.out.println("localDate = " + localDate);
        System.out.println(LocalDate.now());
        System.out.println(LocalDate.parse("2021-10-10"));

        LocalDateTime localDateTime = LocalDateTime.of(2000, 1, 1, 0, 0, 0);
        System.out.println(localDateTime);
        System.out.println(LocalDateTime.now());

        LocalTime localTime = LocalTime.of(5, 30, 33);
        System.out.println(localTime);
    }

    static void streamApiTest1() {
        List<String> list = Arrays.asList("Anna", "Arman", "Artur");

        List<String> convertedNames = new ArrayList<>();

        for (String str : list) {
            if (str.endsWith("n")) {
                String ss = str.substring(0, 2);
                convertedNames.add(ss.toUpperCase());
            }
        }

        for (String convertedName : convertedNames) {
            System.out.println("convertedName = " + convertedName);
        }

        list.stream()
                .filter((s) -> s.endsWith("n"))
                .map((s) -> s.substring(0, 2).toUpperCase())
                .forEach(System.out::println);

        Predicate<Integer> evenOrOddPredicate = (i) -> i % 2 == 0;

        System.out.println(evenOrOddPredicate.test(3));
    }

    static void streamApiTest2() {
        List<String> list = Arrays.asList("1", "3", "7", "-1", "22", "1", "-1");

        list.stream()
                .mapToInt(Integer::parseInt)
                .distinct()
                .sorted()
                .forEach(System.out::println);

        int sum = IntStream.range(1, 1000000000)
                .parallel()
                .sum();
        System.out.println("sum = " + sum);
    }

    static Optional<String> stringProcessor(String str) {
        if (str != null && str.length() > 5) {
            return Optional.of(str.toUpperCase());
        }

        return Optional.empty();
    }
}

interface Printable {

    void print(String greeting);

    default void defaultGreeting() {
        System.out.println("This is default Print");
    }

    static String getSubstring(String str, int indexStart, int indexEnd) {
        return str.substring(indexStart, indexEnd);
    }
}


// Lambda expression
// Optional
// Method reference
// Interface default/static methods
// Java Date
// Stream Api